// MODIFIED for use by Flexport. Original file is located at https://github.com/Ashung/Sketch_Swatches/blob/master/Swatches.sketchplugin/Contents/Resources/swatches.js

var swatches = [
  {
    title: "Latitude Colors",
    handler: "init_latitude_colors",
  },
];
